Engine audit reproduction (this workspace)

Build llama-perplexity in work/llama.cpp/build and build-hip. The model, preserved
pre-fix libraries and original pelican source are identified by the manifests.
The scripts use this workspace's existing paths; they are diagnostic utilities,
not a new runtime dependency. Never reuse an output directory.

For the definitive CPU comparison, use a fresh output directory and one block:
  python work/engine_fidelity_audit.py cpu-reference --root work/recheck-fidelity --chunks 1
  python work/engine_fidelity_audit.py vk-fixed --root work/recheck-fidelity --reference work/recheck-fidelity/cpu-reference.kld --tag vk-fixed-vs-cpu
  python work/engine_fidelity_audit.py vk-before --root work/recheck-fidelity --reference work/recheck-fidelity/cpu-reference.kld --tag vk-before-vs-cpu
The CPU run disables devices, operation offload and KV offload. Setting only
-ngl 0 is insufficient on this UMA system. It takes several minutes.

The recorded CPU reference was extracted from the completed first block of a
two-block run; cpu-first-chunk.json records the exact format, count and SHA256.
The unfinished second block is excluded. Large .kld and tensor .bin files remain
in scratch and are excluded from this archive. Requests, responses, logs and
small metadata files are included. Read summary.json for invalid/excluded controls.

The four short-generation arms can be repeated sequentially with:
  python work/engine_diagnosis.py ARM --root work/recheck-short
where ARM is vk-ar, vk-stock-ar, hip-ar or vk-mtp. Run vk-ar first to create the
frozen token fixtures. These tests do not assess the appearance of a final page.

Stop item 23 with its own q38gsq_service.py launcher before repeating benchmarks,
then restore it afterwards. The recorded final state is item 23 running on node B.
